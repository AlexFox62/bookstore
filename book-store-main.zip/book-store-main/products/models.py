from django.db import models
from users.models import User

class ProductCategory(models.Model):
    name = models.CharField(max_length=64, unique=True, verbose_name='Название категории')
    description = models.TextField(blank=True, verbose_name='Описание')

    class Meta:
        verbose_name_plural = 'Product Categories'

    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=256, verbose_name='Название книги')
    author = models.CharField(max_length=100, blank=True, verbose_name='Автор')
    genre = models.CharField(max_length=50, blank=True, verbose_name='Жанр')
    isbn = models.CharField(max_length=13, blank=True, verbose_name='ISBN')  # Убрано unique=True
    image = models.ImageField(upload_to='books/', blank=True, null=True, verbose_name='Изображение')
    description = models.TextField(blank=True, verbose_name='Описание')
    short_description = models.CharField(max_length=64, blank=True, verbose_name='Краткое описание')
    price = models.DecimalField(max_digits=8, decimal_places=2, default=0, verbose_name='Цена')
    category = models.ForeignKey(ProductCategory, on_delete=models.CASCADE, verbose_name='Категория')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата добавления')

    def __str__(self):
        return f"{self.name} | {self.author or 'Неизвестный автор'} | {self.category.name}"

class Basket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Пользователь')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='Книга')
    quantity = models.PositiveIntegerField(default=1, verbose_name='Количество')
    created_timestamp = models.DateTimeField(auto_now_add=True, verbose_name='Дата добавления')

    def __str__(self):
        return f"Корзина для {self.user.username} | Книга {self.product.name}"

    @property
    def sum(self):
        return self.quantity * self.product.price