from django.contrib import admin
from .models import ProductCategory, Product, Basket

@admin.register(ProductCategory)
class ProductCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'author', 'genre', 'price', 'category', 'created_at')
    search_fields = ('name', 'author', 'genre', 'isbn')
    list_filter = ('category', 'genre')
    fields = ('name', 'author', 'genre', 'isbn', 'image', 'description', 'short_description', 'price', 'category')

@admin.register(Basket)
class BasketAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'quantity', 'created_timestamp')
    search_fields = ('user__username', 'product__name')