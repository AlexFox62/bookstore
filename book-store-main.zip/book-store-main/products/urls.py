from django.urls import path
from . import views

app_name = 'products'

urlpatterns = [
    path('', views.index, name='index'),
    path('products/', views.products, name='index'),
    path('products/category/<int:category_id>/', views.products, name='category'),
    path('products/page/<int:page>/', views.products, name='page'),
    path('products/search/', views.search, name='search'),
    path('bestsellers/', views.bestsellers, name='bestsellers'),
    path('basket/', views.basket, name='basket'),
    path('basket-add/<int:product_id>/', views.basket_add, name='basket_add'),
    path('basket-delete/<int:id>/', views.basket_delete, name='basket_delete'),
]