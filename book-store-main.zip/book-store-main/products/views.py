from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.core.paginator import Paginator
from django.db.models import Q, Count
from products.models import Product, ProductCategory, Basket

def index(request):
    featured_books = Product.objects.all().order_by('-id')[5:8]
    top_categories = ProductCategory.objects.annotate(num_products=Count('product')).order_by('-num_products')[:4]
    context = {
        'title': 'Книжный Уголок',
        'books': featured_books,
        'categories': top_categories,  # Добавляем категории
    }
    return render(request, 'products/index.html', context)

def products(request, category_id=None, page=1):
    context = {
        'title': 'Каталог',
        'categories': ProductCategory.objects.all(),
        'category_id': category_id,
    }
    if category_id:
        products = Product.objects.filter(category_id=category_id)
    else:
        products = Product.objects.all()
    paginator = Paginator(products, 6)
    products_paginator = paginator.page(page)
    context.update({'products': products_paginator})
    return render(request, 'products/products.html', context)


def search(request):
    query = request.GET.get('q', '').strip()  # Убираем пробелы
    page = request.GET.get('page', 1)
    if query:
        products = Product.objects.filter(
            Q(name__icontains=query) | Q(short_description__icontains=query)  # Используем short_description
        )
    else:
        products = Product.objects.none()
    paginator = Paginator(products, 10)
    try:
        products_paginator = paginator.page(page)
    except:
        products_paginator = paginator.page(1)  # Если страница некорректна, возвращаем первую
    context = {
        'title': f'Поиск: {query}' if query else 'Поиск',
        'products': products_paginator,
        'query': query,
    }
    return render(request, 'products/search.html', context)

def categories(request):
    genre = request.GET.get('genre', '')
    categories = ProductCategory.objects.all()
    products = Product.objects.filter(category__name__icontains=genre) if genre else Product.objects.all()
    context = {
        'title': 'Категории',
        'categories': categories,
        'products': products,
        'selected_genre': genre,
    }
    return render(request, 'products/categories.html', context)

def bestsellers(request):
    products = Product.objects.filter(basket__quantity__gt=0).order_by('-basket__quantity')[:6]
    context = {
        'title': 'Бестселлеры',
        'products': products,
    }
    return render(request, 'products/bestsellers.html', context)


@login_required
def basket(request):
    baskets = Basket.objects.filter(user=request.user)
    total_quantity = sum(basket.quantity for basket in baskets)
    total_price = sum(b.sum for b in baskets)
    context = {
        'title': 'Корзина',
        'baskets': baskets,
        'total_quantity': total_quantity,
        'total_price': total_price,
    }
    return render(request, 'products/basket.html', context)


@login_required
def basket_add(request, product_id):
    action = request.GET.get('action', 'increase')
    product = Product.objects.get(id=product_id)
    baskets = Basket.objects.filter(user=request.user, product=product)

    if not baskets.exists():
        if action != 'decrease':
            Basket.objects.create(user=request.user, product=product, quantity=1)
    else:
        basket = baskets.first()
        if action == 'increase':
            basket.quantity += 1
        elif action == 'decrease' and basket.quantity > 1:
            basket.quantity -= 1
        elif action == 'decrease' and basket.quantity == 1:
            basket.delete()
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
        basket.save()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@login_required
def basket_delete(request, id):
    basket = Basket.objects.get(id=id)
    basket.delete()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))